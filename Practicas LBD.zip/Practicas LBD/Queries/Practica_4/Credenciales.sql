USE PracticasLBD;

INSERT INTO Credencial (ID, Tipo, Foto, idPersona)
values (NEWID(), 'Estudiante', 'foto.jpg', 'B1D16868-95CA-4E25-AC92-4D495F8B2744'), 
(NEWID(), 'Adulto', 'foto.jpg', '1C760246-47BB-4798-A86B-A3162E3EBBBF'),
(NEWID(), 'Adulto', 'foto.jpg', '3D851E11-877B-4315-BF88-8EA4FA426036'),
(NEWID(), 'Estudiante', 'foto.jpg', '58418ED9-0B3E-4201-A17E-7B3E8E052A03'),
(NEWID(), 'Estudiante', 'foto.jpg', '617DE673-CDF0-4C69-B8D5-B908C2CB11A0'),
(NEWID(), 'Adulto', 'foto.jpg', '6D81A774-2158-425C-997A-497C909EFFF3'),
(NEWID(), 'Estudiante', 'foto.jpg', 'F809F71A-A644-413B-93C3-582A1DED58B2'),
(NEWID(), 'Adulto', 'foto.jpg', '11BF99FF-DD86-4D85-8903-01F23354BD30'),
(NEWID(), 'Adulto', 'foto.jpg', '41BE2F4E-60E7-4C8F-8FB6-AC6129F07F5A'),
(NEWID(), 'TerceraEdad', 'foto.jpg', '6A7D6FC8-C66F-42D5-8FEA-C3762E92570B');

update Credencial set Tipo='TerceraEdad' where idPersona='3D851E11-877B-4315-BF88-8EA4FA426036';
update Credencial set Foto='Imagen1.jpg' where ID='0DDACCD3-D8A5-4B7C-94B5-FB9B7E0B1567';
update Credencial set Foto='Imagen05.jpg' where ID='50B7B185-5564-46DB-8529-22DE5FD8C126';
update Credencial set Tipo='Estudiante' where ID='96993E63-BE96-433F-9ADE-A01FD94020BA';
update Credencial set Tipo='Adulto' where ID='760DE7F2-0E7B-419C-870C-FE40D765B713';

delete Credencial where ID='50B7B185-5564-46DB-8529-22DE5FD8C126';
delete Credencial where idPersona='3D851E11-877B-4315-BF88-8EA4FA426036';
delete Credencial where ID='FB099CB6-FA39-4F59-B7AC-37754D512C44';
delete Credencial where idPersona='B1D16868-95CA-4E25-AC92-4D495F8B2744';
delete Credencial where ID='0DDACCD3-D8A5-4B7C-94B5-FB9B7E0B1567';

insert into Credencial (ID,Tipo,Foto,idPersona)
values (NEWID(), 'Adulto', 'img.jpg', '8E606853-3BCD-4ADB-9971-B8D32AF37ED6'),
(NEWID(), 'Adulto', 'img1.jpg', 'FEB5B820-924F-461C-AF91-5957788AC5F7'),
(NEWID(), 'TerceraEdad', 'img2.jpg', 'F659B784-4F79-4705-88EB-F0FE5363DC25'),
(NEWID(), 'Adulto', 'img3.jpg', 'B63279AD-9D88-47B9-9B92-E6A3195464F9'),
(NEWID(), 'Estudiante', 'img4.jpg', '68E50C01-0ECA-427C-85E1-9AACBF3B6144')

SELECT * FROM Credencial;