USE PracticasLBD;

INSERT INTO Empleado (ID, FechaIngreso, Puesto, HorasSemanales, SueldoHora, idPersona)
values (NEWID(), '2017/11/08', 'Chofer', '25', '30', '36da8a8e-2d64-4e1e-9000-2be95d452188'),
(NEWID(), '2017/11/08', 'Aseo', '40', '35', '2a603610-7901-4739-8fef-2df6141f1307'),
(NEWID(), '2017/11/10', 'Chofer', '40', '40', '950612a3-e1a4-4f7d-8d03-44cbab53e2ba'),
(NEWID(), '2017/11/10', 'Chofer', '20', '20', '35121d60-e435-426c-85aa-b9879a1b9b35'),
(NEWID(), '2017/11/10', 'Mec�nico', '15', '50', '4ee33695-7661-475c-877e-953f8057391b'),
(NEWID(), '2017/11/10', 'Gerente', '48', '40', '4E84AD25-3B75-4305-8C5E-0B7BF0FF96A0'),
(NEWID(), '2017/11/09', 'Aseo', '16', '25', '52E78651-1326-4CF6-977D-2424DA778936'),
(NEWID(), '2017/11/11', 'Cajero', '48', '22', 'B6C05D76-82BF-4AF1-A44C-3718C6F95680'),
(NEWID(), '2017/11/11', 'Cajero', '27', '28', '0AF457B1-E3A1-419C-B3AE-80496B3376E9'),
(NEWID(), '2017/11/11', 'Chofer', '48', '50', 'C804ADA4-E9DD-472F-A5B0-C970CD6678E2');

update Empleado set Puesto='Chofer', HorasSemanales='20', SueldoHora='20' where ID='FC15F27F-790E-4E38-A7BB-EC58A1449B16';
update Empleado set SueldoHora='23' where ID='2994CD94-D319-414E-9B46-7CF3DA4977C3';
update Empleado set SueldoHora='40' where ID='5842974C-85C7-4B48-BD37-D7098B6605D1';
update Empleado set HorasSemanales='30' where ID='4A7FCF44-1454-419F-A058-112B5B3ECB35';
update Empleado set HorasSemanales='20' where ID='DEC4A6BF-BC63-4E6D-90E5-E6E03E321E6E';

delete Empleado where SueldoTotal='1920';
delete Empleado where Puesto='Gerente';
delete Empleado where ID='33A3BDD4-554A-4934-ADE5-28E5623968CD';
delete Empleado where FechaIngreso='2017-11-09';
delete Empleado where HorasSemanales='30';

insert into Empleado (ID, FechaIngreso, Puesto, HorasSemanales, SueldoHora, idPersona)
values (NEWID(),'2017/12/04','Cajero','20','20','123C47F4-AC20-4779-B48E-5A387DB6B0F0'),
(NEWID(),'2017/12/04','Gerente','48','35','0520B875-469D-4BF3-9602-E08DAFF68EFD'),
(NEWID(),'2017/12/05','Chofer','42','23','054BD2BF-2786-478A-9F61-4773CF71CD27'),
(NEWID(),'2017/12/05','Chofer','30','23','2B4AF291-0AE3-4C93-BE59-E985C192FB84'),
(NEWID(),'2017/12/05','Chofer','48','30','85FCFE38-19EE-4589-AE91-DA2D3DBBF60B');

SELECT * FROM Empleado;