USE PracticasLBD;

INSERT INTO Persona (ID, Nombre, ApellidoP, ApellidoS, FechaNacimiento)
values (NEWID(), 'Jos�', 'Madero', 'Vizca�no', '1980/09/27'), (NEWID(), 'Arturo', 'Arredondo', 'Trevi�o', '1990/12/13'),
(NEWID(), 'Ricardo', 'Trevi�o', 'Arteaga', '1978/10/02'), (NEWID(), 'Jorge', 'Vazquez', 'Vazquez', '1980/03/31'),
(NEWID(), 'Abelardo', 'Vazquez', 'Gonzalez', '1992/02/14'), (NEWID(), 'Isaac', 'Garza', 'Gomez', '1989/08/12'),
(NEWID(), 'Jaime Humberto', 'Beltr�n', 'Alvarado', '1968/06/17'), (NEWID(), 'Luis Francisco', 'Rodriguez', 'Beltr�n', '1998/05/01'),
(NEWID(), 'Alexis Hiram', 'Maldonado', 'Lopez', '1996/07/07'), (NEWID(), 'Isa�', 'Jimenez', 'Madero', '1965/01/31');

update Persona set FechaNacimiento='1981/09/17' where ID='36DA8A8E-2D64-4E1E-9000-2BE95D452188';
update Persona set Nombre='Alexis Iram' where Nombre='Alexis Hiram';
update Persona set ApellidoS='Zapata' where FechaNacimiento='1980-03-31';
update Persona set Nombre='Luis', FechaNacimiento='1998/05/21' where ID='60C5ABF3-6332-4A9F-A7CA-54AF44DBCAF4';
update Persona set ApellidoS='Galvan' where Nombre='Jorge';

delete Persona where Nombre='Luis';
delete Persona where ApellidoP='Vazquez';
delete Persona where ApellidoS='Trevi�o';
delete Persona where FechaNacimiento='1989-08-12';

insert into Persona (ID, Nombre, ApellidoP, ApellidoS, FechaNacimiento)
values (NEWID(),'Juanes', 'de la Garza', 'Garza', '1992/04/15'), (NEWID(),'Marcos', 'Romero', 'Salas', '1992/10/30'),
(NEWID(),'Margarita', 'Garza', 'Casas', '1984/12/28'), (NEWID(),'Diego', 'Martinez', 'Lopez', '1991/08/26'),
(NEWID(),'Diego Antonio', 'Barraza', 'Cantu', '1980/03/27');

insert into Persona (ID, Nombre, ApellidoP, ApellidoS, FechaNacimiento)
values (NEWID(), 'Valeria','Dolores', 'Valdez', '2005/11/10'), (NEWID(), 'Josefa Dolores','Martinez', 'Lara', '1995/09/15'),
(NEWID(), 'Leticia','Montez', 'Gutierrez', '1996/07/13'), (NEWID(), 'Alexia Sofia','D�az', 'Manta', '2010/01/23'),
(NEWID(), 'Gonzalo','Montez', 'Lopez', '2001/10/26'), (NEWID(), 'M�nica','Romero', 'Sanchez', '1985/07/03'),
(NEWID(), 'Roberto','Loreto', 'Macias', '1998/09/30'), (NEWID(), 'Angel','de Leon', 'Salazar', '1990/12/23'),
(NEWID(), 'Rodrigo','Orozco', 'Garc�a', '1994/08/14'), (NEWID(), 'Yoselin','Ramirez', 'Casillas', '1983/07/30');

update Persona set FechaNacimiento='1952/07/30' where FechaNacimiento='1983/07/30';

insert into Persona (ID, Nombre, ApellidoP, ApellidoS, FechaNacimiento)
values(NEWID(), 'Mabel', 'Garza', 'Guevara', '1996/09/30'), (NEWID(), 'Alessandra', 'Milan', 'Noyola','1986/02/22'),
(NEWID(), 'Sergio', 'Cavazos', 'Lugo', '1964/03/15'), (NEWID(), 'Valeria', 'Valdes', 'Brise�o', '1987/04/18'),  
(NEWID(), 'Angela', 'Salda�a', 'Medina', '1994/11/02');

insert into Persona (ID, Nombre, ApellidoP, ApellidoS, FechaNacimiento)
values (NEWID(),'Eduardo', 'Cort�z', 'Cabello','1951/10/14'), (NEWID(),'Raul', 'Aguirre', 'Aguilar','1961/06/01'),
(NEWID(),'Maricela', 'Galarza', 'Cruz','1998/08/02'), (NEWID(),'Daniela Alberta', 'Alanis', 'Escobedo','1978/02/25'),
(NEWID(),'Jos� Gerardo', 'Plata', 'Zamarripa','1970/11/24');

SELECT * FROM Persona;


