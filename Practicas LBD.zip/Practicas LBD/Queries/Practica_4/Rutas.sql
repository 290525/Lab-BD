USE PracticasLBD;

INSERT INTO Rutas (ID, CiudadOrigen, FechaSalida, CiudadDestino, FechaLlegada)
values (NEWID(), 'Monterrey', '2018/03/24 00:20:30', 'Toluca', '2018/03/25 00:12:15'),
(NEWID(), 'Monterrey', '2018/03/26 00:18:45', 'Mazatlan', '2018/03/27 00:08:05'), (NEWID(), 'Monterrey', '2018/03/19 00:06:00', 'Cancun', '2018/03/19 00:21:00'),
(NEWID(), 'Monterrey', '2018/03/29 00:15:30', 'Baja California', '2018/03/30 00:00:45'), 
(NEWID(), 'Monterrey', '2018/07/25 00:08:15', 'Aguascalientes', '2018/07/25 00:12:40'), (NEWID(), 'Saltillo', '2018/06/15 00:16:20', 'Monterrey', '2018/06/15 00:22:05'),
(NEWID(), 'Matacanes', '2018/03/31 00:07:30', 'Monterrey', '2018/03/31 00:10:15'), (NEWID(), 'Oaxaca', '2018/10/24 00:21:15', 'Toluca', '2018/10/24 00:23:55'),
(NEWID(), 'Monterrey', '2018/08/14 00:16:30', 'Queretaro', '2018/08/15 00:00:20'),
(NEWID(), 'Real de Catorce', '2018/04/27 00:17:45', 'Santiago', '2018/07/27 00:20:15');

update Rutas set FechaSalida='2018/10/24 00:21:00' where ID='B3FF3A43-1BC3-49C0-8E58-3FBED33079DF';
update Rutas set FechaLlegada='2018-03-27 00:08:05.000' where ID='7F93B467-27C7-4320-B71F-848CADD5CE35';
update Rutas set CiudadDestino='Baja California Sur' where ID='755786D4-B297-48AF-B0AA-B6A83DD20FC1';
update Rutas set CiudadOrigen='Santiago' where ID='21EFDFC3-F5EF-4BBD-A7A0-8B4E21865525';
update Rutas set FechaLlegada='2018-03-19 00:21:45.000', FechaSalida='2018-03-19 00:06:40.000' WHERE ID='B3753A65-5DA1-40FB-AEB1-C05C2B149436';

delete Rutas where ID='7D42C3B1-209B-4678-A4C3-B048F6801703';
delete Rutas where ID='7F93B467-27C7-4320-B71F-848CADD5CE35';
delete Rutas where ID='3057FC1A-E076-4C35-95BD-3B831D351FBB';
delete Rutas where ID='41F1C27F-6068-41FC-B6AA-B7804ADAFF1F';
delete Rutas where ID='755786D4-B297-48AF-B0AA-B6A83DD20FC1';

insert into Rutas (ID, CiudadOrigen, FechaSalida, CiudadDestino, FechaLlegada)
values (NEWID(),'Monterrey', '2018/04/04 00:19:45', 'Saltillo', '2018/04/04 00:21:45'),(NEWID(),'Mazatlan', '2018/07/16 00:14:05', 'Toluca', '2018/07/16 00:17:45'),
(NEWID(),'Montemorelos', '2018/01/02 00:08:10', 'Santiago', '2018/01/02 00:13:50'),(NEWID(),'Monterrey', '2018/09/12 00:18:30', 'Juarez', '2018/09/12 00:20:10'),
(NEWID(),'Yucatan', '2018/10/27 00:16:40', 'Monterrey', '2018/10/28 00:09:00');

SELECT * from Rutas;