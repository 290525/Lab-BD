USE PracticasLBD;

SELECT * FROM Camion WHERE NoCamion='965';
SELECT * FROM Empleado WHERE Puesto='Chofer';
SELECT * FROM Rutas WHERE FechaSalida='2018-03-31 00:07:30';
SELECT * FROM Cliente WHERE ID='0f637ed5-c9c1-4aa8-b60b-72aa765408e8';
SELECT * FROM Credencial WHERE idPersona='11bf99ff-dd86-4d85-8903-01f23354bd30';

SELECT FechaIngreso, Puesto FROM Empleado GROUP BY FechaIngreso, Puesto;
SELECT Matricula FROM Camion GROUP BY Matricula;
SELECT ID FROM Venta GROUP BY ID;
SELECT Nombre, FechaNacimiento FROM Persona GROUP BY Nombre, FechaNacimiento;
SELECT FechaSalida, FechaLlegada FROM Rutas GROUP BY FechaSalida, FechaLlegada;

SELECT SUM(Ingresos) FROM Venta;
SELECT COUNT(BoletosVendidos) FROM Venta;
SELECT MAX(SueldoTotal) FROM Empleado;
SELECT MIN(SueldoTotal) FROM Empleado;
SELECT AVG(HorasSemanales) FROM Empleado;

SELECT ID, Nombre FROM Persona GROUP BY ID, Nombre HAVING Nombre='Isa�';
SELECT Puesto, SueldoHora, SueldoTotal FROM Empleado GROUP BY Puesto, SueldoHora, SueldoTotal HAVING SueldoTotal>1000;
SELECT ID, idPersona FROM Credencial GROUP BY ID, idPersona HAVING idPersona='6d81a774-2158-425c-997a-497c909efff3';
SELECT PrecioBoleto, BoletosVendidos FROM Venta GROUP BY PrecioBoleto, BoletosVendidos HAVING PrecioBoleto>0;
SELECT Asientos FROM Camion GROUP BY Asientos HAVING Asientos<50;

SELECT TOP 5 Nombre FROM Persona;
SELECT TOP 3 HorasSemanales FROM Empleado;
SELECT TOP 1 MAX(NoCamion) FROM Camion;
SELECT TOP 4 FechaLlegada, FechaSalida FROM Rutas;
SELECT TOP 1 MIN(Ingresos) FROM Venta;