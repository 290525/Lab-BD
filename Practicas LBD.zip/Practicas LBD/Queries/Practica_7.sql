USE PracticasLBD;

CREATE VIEW vwAsientos AS SELECT Asientos, AsientosDisponibles, AsientosOcupados FROM Camion;
CREATE VIEW vwEmpleados AS SELECT idPersona, Puesto, SueldoTotal FROM Empleado;
CREATE VIEW vwPersonas AS SELECT Nombre, ID FROM Persona;
CREATE VIEW vwRutas AS SELECT CiudadOrigen, CiudadDestino FROM Rutas;
CREATE VIEW vwVentas AS SELECT Ingresos FROM Venta;

SELECT * FROM vwVentas GROUP BY Ingresos HAVING Ingresos>0;
SELECT * FROM vwAsientos GROUP BY AsientosDisponibles, Asientos, AsientosOcupados HAVING Asientos>10;
SELECT * FROM vwEmpleados GROUP BY Puesto, idPersona, SueldoTotal;
SELECT * FROM vwPersonas GROUP BY Nombre, ID;
SELECT * FROM vwPersonas JOIN vwEmpleados ON vwPersonas.ID=vwEmpleados.idPersona;
