USE PracticasLBD;

CREATE PROCEDURE BuscarIngresos @Precio money AS SELECT * FROM Venta WHERE PrecioBoleto=@Precio;
execute BuscarIngresos '50';
CREATE PROCEDURE BuscarAsientos @IdRuta uniqueidentifier AS SELECT NoCamion, AsientosDisponibles FROM Camion WHERE idRutas=@IdRuta;
execute BuscarAsientos '7d211d24-ef78-4112-8aab-e3fd583be53c';
CREATE PROCEDURE BuscarEmpleados @Puesto nvarchar(50) AS SELECT * FROM Empleado WHERE Puesto=@Puesto;
execute BuscarEmpleados 'Cajero';
CREATE PROCEDURE BuscarPersonas @Nombre nvarchar(50) AS SELECT * FROM Persona WHERE Nombre=@Nombre;
execute BuscarPersonas 'Isa�';
CREATE PROCEDURE BuscarRutas @ID uniqueidentifier AS SELECT * FROM Rutas WHERE ID=@ID;
execute BuscarRutas 'f2612393-97d8-43c3-807f-adf9fc78f657';

CREATE FUNCTION IVA (@Ingresos money) returns money AS 
	begin declare @Total money set @Total=@Ingresos + (@Ingresos*0.16) return @Total end;
SELECT PrecioBoleto, Ingresos, dbo.IVA(Ingresos) AS Total FROM Venta;
CREATE FUNCTION PersonaEmpleado (@Puesto nvarchar(50)) returns @Personas table (Nombre nvarchar(50), ApellidoP nvarchar(50), ApellidoS nvarchar(50)) AS
	begin INSERT @Personas SELECT Nombre, ApellidoP, ApellidoS FROM Empleado inner join Persona on Persona.ID=Empleado.idPersona WHERE Puesto=@Puesto return end;
SELECT * FROM PersonaEmpleado ('Aseo');

CREATE TRIGGER trCamion ON Camion AFTER UPDATE AS begin insert into Camion (AsientosOcupados) VALUES (0) end;
CREATE TRIGGER trPersona ON Persona INSTEAD OF INSERT AS begin insert into Persona (Nombre, ApellidoP, ApellidoS) VALUES ('','','') end;
